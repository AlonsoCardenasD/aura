
import React, { useState, useEffect, useCallback } from 'react';
import { PillarKey, AutonomyLevel, MemoryNode, Entity } from './types.ts';
import { PILLARS } from './constants.ts';
import { extractEntities } from './services/geminiService.ts';
import { 
    signIn, 
    onAuthStateChanged, 
    fetchMemoryNodes, 
    saveMemoryNode, 
    updateMemoryNode, 
    fetchAutonomyLevels, 
    saveAutonomyLevels 
} from './services/firebaseService.ts';
import type { User } from 'firebase/auth';

import SettingsModal from './components/SettingsModal.tsx';
import AuraCore from './components/AuraCore.tsx';
import TimelineView from './components/TimelineView.tsx';
import DetailPanel from './components/DetailPanel.tsx';
import FilterBar from './components/FilterBar.tsx';
import ActiveFilterBar from './components/ActiveFilterBar.tsx';
import AmbientVisualizer from './components/AmbientVisualizer.tsx';

function App() {
  const [memoryNodes, setMemoryNodes] = useState<MemoryNode[]>([]);
  const [activeNode, setActiveNode] = useState<MemoryNode | null>(null);
  const [filteredPillar, setFilteredPillar] = useState<PillarKey | null>(null);
  const [entityFilter, setEntityFilter] = useState<Entity | null>(null);

  const [isExtracting, setIsExtracting] = useState(false);
  const [isAuraActive, setIsAuraActive] = useState(false);
  const [isSettingsOpen, setSettingsOpen] = useState(false);

  const [user, setUser] = useState<User | null>(null);
  const [isLoadingApp, setIsLoadingApp] = useState(true);

  const [autonomyLevels, setAutonomyLevels] = useState<{ [key in PillarKey]: AutonomyLevel }>(() => {
    return Object.values(PillarKey).reduce((acc, key) => {
        acc[key] = AutonomyLevel.ASSISTANT;
        return acc;
    }, {} as { [key in PillarKey]: AutonomyLevel });
  });
  
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(async (firebaseUser) => {
        if (firebaseUser) {
            setUser(firebaseUser);
            
            const [nodes, levels] = await Promise.all([
                fetchMemoryNodes(firebaseUser.uid),
                fetchAutonomyLevels(firebaseUser.uid)
            ]);
            
            setMemoryNodes(nodes);
            
            if (levels) {
                setAutonomyLevels(levels);
            } else {
                const initialLevels = Object.values(PillarKey).reduce((acc, key) => {
                    acc[key] = AutonomyLevel.ASSISTANT;
                    return acc;
                }, {} as { [key in PillarKey]: AutonomyLevel });
                setAutonomyLevels(initialLevels);
                await saveAutonomyLevels(firebaseUser.uid, initialLevels);
            }
            setIsLoadingApp(false);
        } else {
            try {
                await signIn();
            } catch (error) {
                console.error("Anonymous sign-in failed:", error);
                setIsLoadingApp(false);
            }
        }
    });
    return () => unsubscribe();
  }, []);

  const handleSelectNode = useCallback(async (node: MemoryNode) => {
      if (activeNode?.id === node.id && node.entities) {
          setActiveNode(node);
          return;
      };

      setActiveNode({ ...node, entities: node.entities || [] }); 
      
      if (!node.entities) {
          setIsExtracting(true);
          const extracted = await extractEntities(node.content);
          
          if (user && node.id) {
              await updateMemoryNode(user.uid, node.id, { entities: extracted });
          }
          
          const updatedNode = { ...node, entities: extracted };
          
          setMemoryNodes(prevNodes => 
              prevNodes.map(n => n.id === node.id ? updatedNode : n)
          );
          setActiveNode(updatedNode);
          
          setIsExtracting(false);
      }
  }, [activeNode, user]);

  useEffect(() => {
    if(isAuraActive && memoryNodes.length > 0 && !activeNode) {
        const sortedNodes = [...memoryNodes].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        if (sortedNodes.length > 0) {
            handleSelectNode(sortedNodes[0]);
        }
    }
  }, [isAuraActive, memoryNodes, activeNode, handleSelectNode]);

  const handleSetAutonomyLevel = async (pillarKey: PillarKey, level: AutonomyLevel) => {
    if (!user) return;
    const newLevels = { ...autonomyLevels, [pillarKey]: level };
    setAutonomyLevels(newLevels);
    await saveAutonomyLevels(user.uid, newLevels);
  };

  const handleCreateMemory = async (text: string) => {
    if (!user) return;
    
    const title = text.split(' ').slice(0, 5).join(' ') + '...';
    const newMemory: Omit<MemoryNode, 'id'> = {
      pillarKey: PillarKey.PRODUCTIVITY, 
      title: title,
      createdAt: new Date().toISOString(),
      content: text,
      entities: [],
    };
    
    const savedNode = await saveMemoryNode(user.uid, newMemory as MemoryNode);
    setMemoryNodes(prev => [savedNode, ...prev]);
    await handleSelectNode(savedNode);
  };
  
  const handleEntityClick = (entity: Entity) => {
    setEntityFilter(entity);
    setActiveNode(null); 
  };

  const clearEntityFilter = () => {
    setEntityFilter(null);
  };
  
  const filteredNodes = memoryNodes.filter(node => {
    if (entityFilter) {
        return node.content.toLowerCase().includes(entityFilter.text.toLowerCase());
    }
    return !filteredPillar || node.pillarKey === filteredPillar;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  if (isLoadingApp) {
      return (
        <div className="bg-slate-900 h-screen flex flex-col items-center justify-center text-center p-8 text-slate-400">
             <div className="relative w-40 h-40 bg-slate-800 rounded-full flex items-center justify-center border border-slate-700 shadow-2xl shadow-black mb-12">
                <div className="w-20 h-20 bg-blue-500 rounded-full shadow-lg shadow-blue-500/50 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5a6 6 0 00-6-6v-1.5a6 6 0 00-6 6v1.5a6 6 0 006 6z" /></svg>
                </div>
                <div className={`absolute inset-0 rounded-full border-2 border-slate-500 animate-spin`} style={{animationDuration: '1s'}}></div>
            </div>
            <h1 className="text-2xl font-bold text-white">Estableciendo Conexión Simbiótica...</h1>
            <p className="text-lg text-slate-500 mt-2">Inicializando protocolos de memoria de Aura.</p>
        </div>
      );
  }

  if (!isAuraActive) {
    return <AuraCore onActivate={() => setIsAuraActive(true)} isCentral={true} />;
  }

  return (
    <div className="bg-slate-900 text-slate-200 h-full flex antialiased overflow-hidden selection:bg-blue-500/30">
        <AmbientVisualizer />
        <div className="flex-1 flex flex-col overflow-hidden relative">
            <header className="p-4 border-b border-slate-800 flex justify-between items-center z-20 shrink-0 bg-slate-900/80 backdrop-blur-sm">
                <div className="flex items-center gap-2">
                    <svg viewBox="0 0 100 100" className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="4">
                        <circle cx="50" cy="50" r="30" />
                        <circle cx="50" cy="50" r="45" strokeOpacity="0.5"/>
                    </svg>
                    <h1 className="text-xl font-bold text-white">Aura</h1>
                </div>
                 <FilterBar 
                    activePillar={filteredPillar}
                    onPillarClick={key => { setFilteredPillar(key); clearEntityFilter(); }}
                 />
                 <div>
                    <button onClick={() => setSettingsOpen(true)} className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-full transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.096 2.572-1.065z" />
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </button>
                 </div>
            </header>
            
            {entityFilter && <ActiveFilterBar activeEntity={entityFilter} onClear={clearEntityFilter} />}
            
            <main className="flex-1 overflow-y-auto scrollbar-thin-future">
                <TimelineView 
                    nodes={filteredNodes}
                    activeNode={activeNode}
                    onSelectNode={handleSelectNode}
                />
            </main>
            
            <div className="absolute bottom-8 right-8 z-30">
                <AuraCore onMemoryCapture={handleCreateMemory} isCentral={false}/>
            </div>

        </div>

        <DetailPanel 
            node={activeNode}
            isOpen={!!activeNode}
            onClose={() => setActiveNode(null)}
            isExtractingEntities={isExtracting}
            autonomyLevel={activeNode ? autonomyLevels[activeNode.pillarKey] : AutonomyLevel.ASSISTANT}
            onEntityClick={handleEntityClick}
        />
      
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setSettingsOpen(false)}
        autonomyLevels={autonomyLevels}
        onSetLevel={handleSetAutonomyLevel}
      />
    </div>
  );
}

export default App;
