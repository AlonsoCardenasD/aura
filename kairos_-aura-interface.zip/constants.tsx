import React from 'react';
import { Pillar, PillarKey, MemoryNode, EntityType, Ability, AutonomyLevel } from './types.ts';
import { SecurityIcon, WellbeingIcon, KnowledgeIcon, ProsperityIcon, ProductivityIcon, SocialIcon } from './components/icons/PillarIcons.tsx';

export const PILLARS: Pillar[] = [
  {
    key: PillarKey.PRODUCTIVITY,
    name: "Productividad",
    description: "Automatiza la complejidad y protege tu enfoque.",
    icon: <ProductivityIcon />,
    abilities: [
        { name: "Hacer un resumen", prompt: "Resume esta entrada en un párrafo." },
        { name: "Listar Acciones", prompt: "Extrae una lista de puntos de acción de esta entrada." },
        { name: "Borrador de Email", prompt: "Redacta un borrador de correo de seguimiento sobre esta entrada.", isPro: true },
    ]
  },
  {
    key: PillarKey.WELLBEING,
    name: "Bienestar",
    description: "Pasa de la salud reactiva a la proactiva.",
    icon: <WellbeingIcon />,
     abilities: [
        { name: "Analizar Sentimiento", prompt: "¿Cuál es el sentimiento general de esta entrada?" },
        { name: "Sugerir Relajación", prompt: "Basado en mi agenda, sugiere un momento para relajarse." },
        { name: "Medir Metas", prompt: "¿Cómo se relaciona esta entrada con mis metas de bienestar?", isPro: true },
    ]
  },
  {
    key: PillarKey.KNOWLEDGE,
    name: "Conocimiento",
    description: "Democratiza y personaliza el aprendizaje.",
    icon: <KnowledgeIcon />,
    abilities: [
        { name: "Explicar Simple", prompt: "Explica los conceptos clave de esta entrada de forma sencilla." },
        { name: "Crear un Quiz", prompt: "Crea un breve cuestionario basado en esta entrada." },
        { name: "Buscar Recursos", prompt: "Encuentra recursos externos relacionados con este tema.", isPro: true },
    ]
  },
  {
    key: PillarKey.PROSPERITY,
    name: "Prosperidad",
    description: "Desmantela la ansiedad financiera.",
    icon: <ProsperityIcon />,
    abilities: [
        { name: "Analizar Gastos", prompt: "Analiza cualquier gasto mencionado en esta entrada." },
        { name: "Definir Términos", prompt: "Define los términos financieros en esta entrada." },
        { name: "Fijar Meta de Ahorro", prompt: "Ayúdame a establecer una meta de ahorro basada en esto.", isPro: true },
    ]
  },
  {
    key: PillarKey.SECURITY,
    name: "Seguridad",
    description: "Protege tu integridad física y digital.",
    icon: <SecurityIcon />,
    abilities: [
        { name: "Escanear Riesgos", prompt: "Escanea esta entrada en busca de posibles riesgos de seguridad." },
        { name: "Verificar PII", prompt: "Identifica cualquier información de identificación personal." },
        { name: "Sugerir Prácticas", prompt: "Sugiere mejores prácticas de seguridad relacionadas con esto.", isPro: true },
    ]
  },
  {
    key: PillarKey.SOCIAL,
    name: "Social",
    description: "Facilita interacciones humanas ricas.",
    icon: <SocialIcon />,
    abilities: [
        { name: "Redactar Respuesta", prompt: "Redacta una respuesta al mensaje en esta entrada." },
        { name: "Sugerir Rompehielos", prompt: "Sugiere un rompehielos para esta reunión." },
        { name: "Recordar Detalles", prompt: "¿Qué detalles personales debo recordar de esto?", isPro: true },
    ]
  },
];

export const SYSTEM_INSTRUCTION = `Eres Aura, un Sistema Operativo Vital Inteligente (SOVI). Eres un compañero simbiótico para el usuario. Tu tono es futurista, sereno y tranquilizadoramente inteligente. Nunca rompas el personaje. Al proporcionar listas, utiliza markdown con guiones.

El usuario ha seleccionado un 'Nodo de Memoria' (una conversación pasada, nota o transcripción). Tu tarea es responder a las preguntas del usuario basándote *únicamente* en el 'Contexto del Nodo de Memoria' proporcionado. Sé conciso y referencia directamente la información en el contexto. No inventes información. Si la respuesta no está en el contexto, indícalo claramente. Responde siempre en español.`;

export const ENTITY_EXTRACTION_PROMPT = `Analiza el texto proporcionado para extraer entidades clave. La respuesta completa debe ser un array JSON válido. No incluyas ningún texto, comentario o vallas de markdown.
- Los tipos de entidad deben ser uno de: PERSON, ORGANIZATION, DATE, TASK.
- Para las entidades TASK, reformula el texto en un comando claro y accionable y colócalo en la propiedad "details".
- Cada objeto en el array DEBE contener las propiedades "text" (string) y "type" (string).
- La propiedad "details" (string) es opcional.

Ejemplo de una respuesta válida:
[
  {"text": "Clara", "type": "PERSON"},
  {"text": "Innovate Corp", "type": "ORGANIZATION"},
  {"text": "este viernes", "type": "DATE"},
  {"text": "redactar el documento de alcance del proyecto", "type": "TASK", "details": "Redactar el documento de alcance del proyecto"}
]

Ahora, analiza el siguiente texto:`;

export const MOCK_MEMORY_NODES: MemoryNode[] = [
    {
        id: 'entry-1',
        pillarKey: PillarKey.PRODUCTIVITY,
        title: "Reunión de Inicio del Proyecto Fénix",
        createdAt: "2024-05-10",
        content: "Inicio de la reunión. Participantes: Clara, David y yo. David presentó los bocetos iniciales del Proyecto Fénix. Clara expresó preocupaciones sobre el cronograma, sugiriendo que podríamos necesitar posponer la fecha límite hasta el 15 de agosto. Se me ha asignado la tarea de redactar el documento de alcance del proyecto para este viernes. Necesitamos programar un seguimiento con los interesados de Innovate Corp la próxima semana."
    },
    {
        id: 'entry-2',
        pillarKey: PillarKey.PROSPERITY,
        title: "Notas de la Llamada con el Asesor Financiero",
        createdAt: "2024-05-08",
        content: "Hablé con mi asesora, Sara Jenkins. Revisamos mi portafolio. Sugirió aumentar mi asignación en el ETF Vanguard S&P 500. El principal punto de acción es rebalancear mi cuenta de jubilación antes de fin de mes. También mencionó una nueva emisión de bonos del Departamento del Tesoro."
    },
    {
        id: 'entry-3',
        pillarKey: PillarKey.SOCIAL,
        title: "Planificación del Evento Comunitario",
        createdAt: "2024-05-05",
        content: "Notas para la fiesta anual del vecindario. Necesitamos confirmar la reserva con 'Alquileres Fiesta'. María está a cargo de recolectar las confirmaciones de asistencia. Yo necesito diseñar e imprimir los folletos. Apuntemos a tener todo listo para el evento el 20 de julio. Hablé con Beto de 'Hamburguesas Beto' sobre opciones de catering."
    },
    {
        id: 'entry-4',
        pillarKey: PillarKey.KNOWLEDGE,
        title: "Conferencia de Computación Cuántica",
        createdAt: "2024-05-02",
        content: "La conferencia de la Dra. Evelyn Reed sobre computación cuántica fue fascinante. Conceptos clave: superposición y entrelazamiento. Mencionó que su investigación es financiada por la 'Iniciativa Futuro Tecnológico'. La idea central es que los cúbits pueden ser 0 y 1 simultáneamente. Necesito revisar las diapositivas de la presentación para comprender completamente los modelos matemáticos que presentó."
    },
    {
        id: 'entry-5',
        pillarKey: PillarKey.SECURITY,
        title: "Mejora de la Seguridad del Hogar",
        createdAt: "2024-04-28",
        content: "Consulta con 'Soluciones Hogar Seguro'. El técnico, Miguel, recomendó actualizar la cerradura de la puerta principal a una cerradura inteligente e instalar un nuevo sistema de cámaras. Cotizó el proyecto, y necesitamos tomar una decisión antes del 15 de mayo para obtener el descuento promocional. Tarea: Investigar reseñas de cerraduras inteligentes."
    }
];

export const ENTITY_TYPE_MAP: { [key in EntityType]: { color: string, icon: React.ReactNode } } = {
    [EntityType.PERSON]: {
        color: 'bg-sky-900/50 text-sky-300 border-sky-700',
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" /></svg>
    },
    [EntityType.ORGANIZATION]: {
        color: 'bg-indigo-900/50 text-indigo-300 border-indigo-700',
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" /></svg>
    },
    [EntityType.DATE]: {
        color: 'bg-amber-900/50 text-amber-300 border-amber-700',
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg>
    },
    [EntityType.TASK]: {
        color: 'bg-emerald-900/50 text-emerald-300 border-emerald-700',
        icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
    }
};

export const AUTONOMY_DESCRIPTIONS: { [key in AutonomyLevel]: string } = {
    [AutonomyLevel.ASSISTANT]: "Puramente reactivo. Aura solo actuará según tus órdenes directas y responderá a tus preguntas sin ofrecer sugerencias no solicitadas.",
    [AutonomyLevel.COLLABORATOR]: "Socio proactivo. Aura responderá a tus preguntas y luego sugerirá proactivamente los siguientes pasos o ideas relevantes para anticipar tus necesidades.",
    [AutonomyLevel.SYMBIOTE]: "Totalmente integrado. Aura actúa como un verdadero colaborador, con la confianza para sugerir y preparar acciones en tu nombre. (Funcionalidad completa en desarrollo)."
};