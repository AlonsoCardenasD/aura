import { initializeApp } from "firebase/app";
import { getAuth, signInAnonymously, onAuthStateChanged as onFirebaseAuthStateChanged, User } from "firebase/auth";
import { 
    getFirestore, 
    collection, 
    getDocs, 
    doc, 
    setDoc, 
    addDoc,
    query,
    orderBy,
    updateDoc,
    getDoc
} from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";
import { MemoryNode, PillarKey, AutonomyLevel } from "../types.ts";
import { MOCK_MEMORY_NODES } from "../constants.ts";

const firebaseConfig = {
  apiKey: "AIzaSyDxy_0WSnEJQuxxQYgLTXhzk9k67XgnvTo",
  authDomain: "aura-e4503.firebaseapp.com",
  projectId: "aura-e4503",
  storageBucket: "aura-e4503.firebasestorage.app",
  messagingSenderId: "1037999780679",
  appId: "1:1037999780679:web:d402b7d927b39aec069262",
  measurementId: "G-3LF1X1J6Y5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const analytics = getAnalytics(app);

export const signIn = () => signInAnonymously(auth);
export const onAuthStateChanged = (callback: (user: User | null) => void) => onFirebaseAuthStateChanged(auth, callback);

const getNodesCollection = (userId: string) => collection(db, `users/${userId}/memoryNodes`);
const getSettingsDoc = (userId: string) => doc(db, `users/${userId}/settings/autonomy`);

// Fetch memory nodes for a user
export const fetchMemoryNodes = async (userId: string): Promise<MemoryNode[]> => {
    const q = query(getNodesCollection(userId), orderBy("createdAt", "desc"));
    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) {
        return [];
    }
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MemoryNode));
};

// Save a new memory node
export const saveMemoryNode = async (userId: string, node: MemoryNode): Promise<MemoryNode> => {
    const docRef = await addDoc(getNodesCollection(userId), node);
    return { ...node, id: docRef.id };
};

// Update an existing memory node
export const updateMemoryNode = async (userId: string, nodeId: string, updates: Partial<MemoryNode>): Promise<void> => {
    const nodeDoc = doc(db, `users/${userId}/memoryNodes`, nodeId);
    await updateDoc(nodeDoc, updates);
};

// Fetch autonomy levels for a user
export const fetchAutonomyLevels = async (userId: string): Promise<{ [key in PillarKey]: AutonomyLevel } | null> => {
    const docRef = getSettingsDoc(userId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
        return docSnap.data() as { [key in PillarKey]: AutonomyLevel };
    } else {
        return null;
    }
};

// Save autonomy levels for a user
export const saveAutonomyLevels = async (userId: string, levels: { [key in PillarKey]: AutonomyLevel }): Promise<void> => {
    await setDoc(getSettingsDoc(userId), levels);
};