import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTION, ENTITY_EXTRACTION_PROMPT } from '../constants.tsx';
import { Entity } from "../types.ts";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "fallback" });
const model = "gemini-2.5-flash-preview-04-17";

const handleApiError = (error: unknown, context: string = "calling Gemini API"): string => {
    console.error(`Error ${context}:`, error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            return "Aura está actualmente fuera de línea. La clave de API proporcionada no es válida.";
        }
        return `Aura ha encontrado una anomalía en el sistema: ${error.message}`;
    }
    return "Aura ha encontrado una anomalía desconocida en el sistema.";
}

const parseJsonResponse = <T>(responseText: string): T | null => {
    let jsonStr = responseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
        jsonStr = match[2].trim();
    }

    try {
        return JSON.parse(jsonStr) as T;
    } catch (error) {
        console.error("Failed to parse JSON response:", error, "Raw response:", responseText);
        return null;
    }
};

export const askAura = async (prompt: string, contextText?: string): Promise<string> => {
  if (!API_KEY) {
    return "Aura está actualmente fuera de línea. La clave de API no está configurada.";
  }
  
  try {
    const fullPrompt = `Contexto del Nodo de Memoria:\n---\n${contextText || 'No se proporcionó contexto.'}\n---\n\nPregunta del Usuario: ${prompt}`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model,
      contents: fullPrompt,
      config: { systemInstruction: SYSTEM_INSTRUCTION }
    });

    return response.text.trim();

  } catch (error) {
    return handleApiError(error, "in askAura");
  }
};

export const extractEntities = async (text: string): Promise<Entity[]> => {
    if (!API_KEY) {
        console.warn("Cannot extract entities, API_KEY is not configured.");
        return [];
    }

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model,
            contents: `${ENTITY_EXTRACTION_PROMPT}\n\n${text}`,
            config: {
                responseMimeType: "application/json",
            }
        });

        const parsedData = parseJsonResponse<Entity[]>(response.text);
        if (Array.isArray(parsedData)) {
            return parsedData;
        }
        console.error("Parsed data for entities is not an array:", parsedData);
        return [];

    } catch (error) {
        console.error("Error extracting entities:", error);
        return []; 
    }
};
