import React from 'react';
import { MemoryNode } from '../types.ts';
import TimelineNode from './TimelineNode.tsx';

interface TimelineViewProps {
    nodes: MemoryNode[];
    activeNode: MemoryNode | null;
    onSelectNode: (node: MemoryNode) => void;
}

const TimelineView: React.FC<TimelineViewProps> = ({ nodes, activeNode, onSelectNode }) => {
    return (
        <div className="w-full max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10">
            <div className="relative">
                {/* The timeline line */}
                <div className="absolute left-1/2 -ml-px h-full w-0.5 bg-slate-800"></div>

                <div className="space-y-16">
                    {nodes.map(node => (
                        <TimelineNode 
                            key={node.id}
                            node={node}
                            isActive={activeNode?.id === node.id}
                            onClick={() => onSelectNode(node)}
                        />
                    ))}
                </div>

                 {nodes.length === 0 && (
                    <div className="text-center py-20 text-slate-500">
                        <p className="font-semibold text-lg">La línea de tiempo está vacía.</p>
                        <p>Usa el Núcleo de Aura para capturar tu primera memoria.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TimelineView;