import React from 'react';
import { MemoryNode, PillarKey } from '../types.ts';
import { PILLARS } from '../constants.tsx';

interface TimelineNodeProps {
    node: MemoryNode;
    isActive: boolean;
    onClick: () => void;
}

const TimelineNode: React.FC<TimelineNodeProps> = ({ node, isActive, onClick }) => {
    const pillar = PILLARS.find(p => p.key === node.pillarKey);

    const pillarColors: {[key in PillarKey]: { bg: string, border: string, text: string }} = {
        [PillarKey.PRODUCTIVITY]: { bg: 'bg-slate-800', border: 'border-slate-600', text: 'text-slate-300' },
        [PillarKey.WELLBEING]: { bg: 'bg-rose-900/50', border: 'border-rose-700', text: 'text-rose-300' },
        [PillarKey.KNOWLEDGE]: { bg: 'bg-sky-900/50', border: 'border-sky-700', text: 'text-sky-300' },
        [PillarKey.PROSPERITY]: { bg: 'bg-emerald-900/50', border: 'border-emerald-700', text: 'text-emerald-300' },
        [PillarKey.SECURITY]: { bg: 'bg-indigo-900/50', border: 'border-indigo-700', text: 'text-indigo-300' },
        [PillarKey.SOCIAL]: { bg: 'bg-amber-900/50', border: 'border-amber-700', text: 'text-amber-300' },
    }

    const styles = pillar ? pillarColors[pillar.key] : pillarColors[PillarKey.PRODUCTIVITY];

    return (
        <div className="relative">
            {/* The dot on the timeline */}
            <div className={`absolute left-1/2 -ml-2 top-1 w-4 h-4 rounded-full transition-all duration-300 ${isActive ? 'bg-blue-500 shadow-lg shadow-blue-500/50' : 'bg-slate-700'}`}></div>
            
            <button
                onClick={onClick}
                className={`w-full text-left pl-[calc(50%_+_2rem)] pr-4 py-3 rounded-lg transition-all duration-200 border
                    ${isActive ? 'bg-slate-800 border-blue-500' : 'bg-transparent border-transparent hover:bg-slate-800/50'}
                `}
            >
                <p className={`text-xs font-semibold uppercase tracking-wider mb-1 ${styles.text}`}>{pillar?.name || 'Memoria'}</p>
                <h3 className="font-semibold text-slate-100 mb-1">{node.title}</h3>
                <p className="text-xs text-slate-400">{new Date(node.createdAt).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </button>
        </div>
    );
};

export default TimelineNode;
