import React, { useState, useEffect } from 'react';
import { MemoryNode, AutonomyLevel, Entity, Message, MessageSender, PillarKey } from '../types.ts';
import ContentHighlighter from './ContentHighlighter.tsx';
import { PILLARS } from '../constants.tsx';
import EntityBadge from './EntityBadge.tsx';
import SmartAction from './SmartAction.tsx';
import { askAura } from '../services/geminiService.ts';
import SkeletonLoader from './SkeletonLoader.tsx';
import ChatMessage from './ChatMessage.tsx';

interface SpeechRecognition {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    onresult: (event: any) => void;
    onend: () => void;
    onerror: (event: any) => void;
    start: () => void;
    stop: () => void;
}

declare var webkitSpeechRecognition: {
    new(): SpeechRecognition;
};

// Simple voice-enabled input component for the chat
const VoiceInput: React.FC<{ onSend: (text: string) => void; isLoading: boolean }> = ({ onSend, isLoading }) => {
    const [isListening, setIsListening] = useState(false);
    const recognitionRef = React.useRef<SpeechRecognition | null>(null);

    useEffect(() => {
        if (!('webkitSpeechRecognition' in window)) return;
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'es-MX';
        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            onSend(transcript);
            setIsListening(false);
        };
        recognition.onend = () => setIsListening(false);
        recognition.onerror = () => setIsListening(false);
        recognitionRef.current = recognition;
    }, [onSend]);

    const handleListen = () => {
        if (isLoading || isListening || !recognitionRef.current) return;
        recognitionRef.current.start();
        setIsListening(true);
    };

    return (
        <div className="p-4 bg-slate-900 border-t border-slate-800">
            <button
                onClick={handleListen}
                disabled={isLoading || isListening}
                className="w-full flex items-center justify-center gap-3 bg-blue-600/20 text-blue-300 font-semibold px-4 py-3 rounded-lg border border-blue-500/30 hover:bg-blue-600/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
                {isLoading ? (
                    'Aura está pensando...'
                ) : isListening ? (
                    'Escuchando...'
                ) : (
                    <>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M7 4a3 3 0 016 0v6a3 3 0 11-6 0V4z" /><path fillRule="evenodd" d="M5.5 8.5A.5.5 0 016 9v1a4 4 0 004 4 .5.5 0 010 1 5 5 0 01-5-5V9a.5.5 0 01.5-.5z" clipRule="evenodd" /></svg>
                        Hablar con Aura
                    </>
                )}
            </button>
        </div>
    );
};


interface DetailPanelProps {
    node: MemoryNode | null;
    isOpen: boolean;
    onClose: () => void;
    isExtractingEntities: boolean;
    autonomyLevel: AutonomyLevel;
    onEntityClick: (entity: Entity) => void;
}

const DetailPanel: React.FC<DetailPanelProps> = ({ node, isOpen, onClose, isExtractingEntities, autonomyLevel, onEntityClick }) => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const chatEndRef = React.useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (node) {
            setMessages([]); // Reset chat on new node
        }
    }, [node]);
    
     useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    const handleSend = async (prompt: string) => {
        if (!node || prompt.trim() === '' || isLoading) return;

        const newUserMessage: Message = { id: `user-${Date.now()}`, sender: MessageSender.USER, text: prompt };
        setMessages(prev => [...prev, newUserMessage]);
        setIsLoading(true);

        const auraResponseText = await askAura(prompt, node.content);

        const newAuraMessage: Message = { id: `aura-${Date.now()}`, sender: MessageSender.AURA, text: auraResponseText };
        setMessages(prev => [...prev, newAuraMessage]);
        setIsLoading(false);
    };
    
    const pillar = node ? PILLARS.find(p => p.key === node.pillarKey) : null;
    const smartActions = pillar?.abilities || [];

    return (
        <aside className={`fixed top-0 right-0 h-full w-full max-w-2xl bg-slate-900/80 backdrop-blur-xl border-l border-slate-800 shadow-2xl shadow-black transform transition-transform duration-500 ease-in-out z-40 flex flex-col
            ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        `}>
            {node && (
                <>
                    <header className="p-6 border-b border-slate-800 flex-shrink-0 flex justify-between items-start">
                        <div>
                            <h2 className="text-2xl font-bold text-white truncate">{node.title}</h2>
                            <p className="text-sm text-slate-400">{new Date(node.createdAt).toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        </div>
                         <button onClick={onClose} className="p-2 text-slate-500 hover:text-white hover:bg-slate-700 rounded-full transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </header>
                    
                    <div className="flex-1 flex flex-col xl:flex-row overflow-y-auto scrollbar-thin-future">
                        <div className="flex-1 p-6 space-y-6 overflow-y-auto scrollbar-thin-future xl:border-r xl:border-slate-800">
                             <div>
                                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Contenido</h3>
                                <div className="text-slate-300 leading-relaxed bg-black/20 p-4 rounded-lg border border-slate-800">
                                    <ContentHighlighter text={node.content} entities={node.entities || []} />
                                </div>
                            </div>
                            <div>
                                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Entidades Extraídas</h3>
                                {isExtractingEntities ? <SkeletonLoader type="badges" /> : (
                                    node.entities && node.entities.length > 0 ? (
                                        <div className="flex flex-wrap gap-2">{node.entities.map((entity, index) => <EntityBadge key={index} entity={entity} onClick={() => onEntityClick(entity)} />)}</div>
                                    ) : <p className="text-sm text-slate-500">Aura no encontró entidades clave.</p>
                                )}
                            </div>
                            <div>
                                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Acciones Inteligentes</h3>
                                {isExtractingEntities ? <SkeletonLoader type="actions" /> : (
                                    smartActions.length > 0 ? (
                                        <div className="flex flex-wrap gap-2">{smartActions.map((action) => <SmartAction key={action.name} action={action} onClick={() => handleSend(action.prompt)} />)}</div>
                                    ) : <p className="text-sm text-slate-500">No hay acciones sugeridas.</p>
                                )}
                            </div>
                        </div>
                        <div className="xl:max-w-md 2xl:max-w-lg w-full flex flex-col bg-slate-900 border-t xl:border-t-0 xl:border-l border-slate-800">
                           <div className="flex-1 p-4 md:p-6 space-y-4 overflow-y-auto scrollbar-thin-future">
                                {messages.map(msg => <ChatMessage key={msg.id} message={msg} />)}
                                {isLoading && <ChatMessage key="loading" message={{id: 'loading', sender: MessageSender.AURA, text: '...'}} />}
                                <div ref={chatEndRef} />
                            </div>
                            <VoiceInput onSend={handleSend} isLoading={isLoading} />
                        </div>
                    </div>
                </>
            )}
        </aside>
    );
};

export default DetailPanel;