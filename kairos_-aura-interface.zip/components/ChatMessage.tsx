import React from 'react';
import { Message, MessageSender } from '../types.ts';

interface ChatMessageProps {
  message: Message;
}

const renderInline = (text: string) => {
    // A simple loader for when Aura is thinking
    if (text === '...') {
        return (
             <div className="flex items-center space-x-2 pt-1">
                <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></div>
            </div>
        )
    }

    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g).filter(Boolean);
    return parts.map((part, index) => {
        if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={index} className="text-white">{part.slice(2, -2)}</strong>;
        }
        if (part.startsWith('*') && part.endsWith('*')) {
            return <em key={index}>{part.slice(1, -1)}</em>;
        }
        if (part.startsWith('`') && part.endsWith('`')) {
            return <code key={index} className="bg-slate-900 text-fuchsia-400 px-1 py-0.5 rounded text-sm font-mono">{part.slice(1, -1)}</code>;
        }
        return <span key={index}>{part}</span>;
    });
};

const SimpleMarkdown: React.FC<{ text: string }> = ({ text }) => {
    const blocks = text.split('\n').reduce((acc, line) => {
        const isListItem = line.trim().startsWith('- ');
        const lastBlock = acc[acc.length - 1];

        if (isListItem) {
            if (lastBlock && lastBlock.type === 'ul') {
                lastBlock.items.push(line.trim().substring(2));
            } else {
                acc.push({ type: 'ul', items: [line.trim().substring(2)] });
            }
        } else {
             // Handle multiple newlines as separate paragraphs
             if (line.trim() === '') {
                 acc.push({ type: 'p', content: '' });
             } else if (lastBlock && lastBlock.type === 'p' && lastBlock.content !== '') {
                lastBlock.content += '\n' + line;
            } else {
                acc.push({ type: 'p', content: line });
            }
        }
        return acc;
    }, [] as Array<{type: 'p', content: string} | {type: 'ul', items: string[]}>);

    return (
        <>
            {blocks.map((block, index) => {
                if (block.type === 'p') {
                    if (block.content.trim() === '') return <div key={index} className="h-2"></div>;
                    return <p key={index}>{renderInline(block.content)}</p>;
                }
                if (block.type === 'ul') {
                    return (
                        <ul key={index} className="list-disc list-inside space-y-1 my-2 pl-2">
                            {block.items.map((item, itemIndex) => (
                                <li key={itemIndex}>{renderInline(item)}</li>
                            ))}
                        </ul>
                    );
                }
                return null;
            })}
        </>
    );
};


const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isAura = message.sender === MessageSender.AURA;

  return (
    <div className={`flex items-start gap-3 ${isAura ? '' : 'flex-row-reverse'}`}>
      {isAura ? (
        <div className="flex-shrink-0 w-8 h-8 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center">
          <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
        </div>
      ) : (
        <div className="flex-shrink-0 w-8 h-8 bg-blue-500/20 border border-blue-500/50 rounded-full flex items-center justify-center">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-300" viewBox="0 0 20 20" fill="currentColor">
             <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
           </svg>
        </div>
      )}
      <div
        className={`max-w-md lg:max-w-2xl px-4 py-3 rounded-lg
          ${
          isAura 
            ? 'bg-slate-800 text-slate-300 rounded-tl-none' 
            : 'bg-blue-600/50 text-slate-100 rounded-tr-none'
        }`}
      >
        <div className="prose prose-sm max-w-none text-inherit leading-relaxed">
            <SimpleMarkdown text={message.text} />
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;