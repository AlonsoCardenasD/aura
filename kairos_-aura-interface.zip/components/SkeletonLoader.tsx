import React from 'react';

interface SkeletonLoaderProps {
    type: 'badges' | 'actions';
}

const SkeletonLoader: React.FC<SkeletonLoaderProps> = ({ type }) => {
    if (type === 'badges') {
        return (
            <div className="flex flex-wrap gap-2 animate-pulse">
                <div className="h-7 w-24 bg-slate-800 rounded-full"></div>
                <div className="h-7 w-32 bg-slate-800 rounded-full"></div>
                <div className="h-7 w-20 bg-slate-800 rounded-full"></div>
                <div className="h-7 w-28 bg-slate-800 rounded-full"></div>
            </div>
        );
    }

    if (type === 'actions') {
        return (
            <div className="flex flex-wrap gap-2 animate-pulse">
                <div className="h-9 w-32 bg-slate-800 rounded-lg"></div>
                <div className="h-9 w-40 bg-slate-800 rounded-lg"></div>
            </div>
        );
    }

    return null;
};

export default SkeletonLoader;