import React from 'react';
import { Entity, EntityType } from '../types.ts';

const entityHighlightColors: { [key in EntityType]: string } = {
    [EntityType.PERSON]: 'bg-sky-900/60',
    [EntityType.ORGANIZATION]: 'bg-indigo-900/60',
    [EntityType.DATE]: 'bg-amber-900/60',
    [EntityType.TASK]: 'bg-emerald-900/60',
};

interface ContentHighlighterProps {
    text: string;
    entities: Entity[];
}

const ContentHighlighter: React.FC<ContentHighlighterProps> = ({ text, entities }) => {
    if (!text) return null;
    if (!entities || entities.length === 0) {
        return <p>{text}</p>;
    }

    // Sort by length descending to match longer entities first
    const sortedEntities = [...entities].sort((a, b) => b.text.length - a.text.length);
    const entityTexts = sortedEntities.map(e => e.text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const regex = new RegExp(`(${entityTexts.join('|')})`, 'gi');

    const parts = text.split(regex);

    return (
        <p>
            {parts.map((part, index) => {
                if (!part) return null;
                const entity = sortedEntities.find(e => e.text.toLowerCase() === part.toLowerCase());
                if (entity) {
                    return (
                        <span key={index} className={`${entityHighlightColors[entity.type]} px-1 py-0.5 rounded-sm mx-px`}>
                            {part}
                        </span>
                    );
                }
                return <span key={index}>{part}</span>;
            })}
        </p>
    );
};

export default ContentHighlighter;