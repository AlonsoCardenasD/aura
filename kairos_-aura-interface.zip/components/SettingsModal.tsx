import React from 'react';
import { AutonomyLevel, PillarKey } from '../types.ts';
import { PILLARS, AUTONOMY_DESCRIPTIONS } from '../constants.tsx';

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    autonomyLevels: { [key in PillarKey]: AutonomyLevel };
    onSetLevel: (pillarKey: PillarKey, level: AutonomyLevel) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, autonomyLevels, onSetLevel }) => {
    const [selectedLevel, setSelectedLevel] = React.useState<AutonomyLevel | null>(null);

    if (!isOpen) return null;

    const levels = Object.values(AutonomyLevel);

    return (
        <div 
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 transition-opacity duration-300"
        >
            <div 
                onClick={(e) => e.stopPropagation()}
                className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-black w-full max-w-4xl max-h-[90vh] flex flex-col transform transition-all duration-300 scale-95 opacity-0 animate-fade-in-scale"
                style={{ animationFillMode: 'forwards' }}
            >
                <header className="p-6 border-b border-slate-800 flex justify-between items-center shrink-0">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Pacto de Soberanía</h2>
                        <p className="text-slate-400">Define tu relación y el nivel de autonomía con Aura.</p>
                    </div>
                     <button onClick={onClose} className="p-2 text-slate-500 hover:text-white hover:bg-slate-700 rounded-full transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>
                
                <div className="flex-1 p-6 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-y-auto scrollbar-thin-future">
                    <div className="md:col-span-1 space-y-4">
                       {levels.map(level => (
                           <button 
                                key={level}
                                onClick={() => setSelectedLevel(level)}
                                className={`w-full p-4 rounded-lg border-2 text-left transition-all duration-200 ${selectedLevel === level ? 'bg-blue-500/10 border-blue-500' : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'}`}
                           >
                               <h3 className="font-bold text-lg text-white">{level}</h3>
                               <p className="text-sm text-slate-400 mt-1">{AUTONOMY_DESCRIPTIONS[level]}</p>
                           </button>
                       ))}
                    </div>

                    <div className="md:col-span-2 bg-black/20 p-6 rounded-lg border border-slate-800">
                        <h3 className="font-bold text-lg text-white mb-4">Aplicar a Pilares</h3>
                        <div className="space-y-3">
                            {PILLARS.map(pillar => (
                                <div key={pillar.key} className="flex justify-between items-center bg-slate-800/50 p-3 rounded-lg">
                                    <div className="flex items-center gap-3">
                                        <span className="text-slate-400">{pillar.icon}</span>
                                        <span className="font-semibold text-slate-200">{pillar.name}</span>
                                    </div>
                                    <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg p-1">
                                        {levels.map(level => (
                                            <button 
                                                key={level}
                                                onClick={() => onSetLevel(pillar.key, level)}
                                                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${autonomyLevels[pillar.key] === level ? 'bg-blue-500 text-white' : 'text-slate-400 hover:bg-slate-700/50'}`}
                                            >
                                                {level}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <footer className="p-4 bg-slate-900/50 border-t border-slate-800 text-right shrink-0">
                    <button 
                        onClick={onClose}
                        className="bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg hover:bg-blue-500 transition-colors"
                    >
                        Cerrar
                    </button>
                </footer>
            </div>
             <style>{`
                @keyframes fade-in-scale {
                    from { transform: scale(0.95); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                .animate-fade-in-scale {
                    animation: fade-in-scale 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
            `}</style>
        </div>
    );
};

export default SettingsModal;
