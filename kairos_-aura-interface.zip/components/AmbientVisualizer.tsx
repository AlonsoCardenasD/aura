import React, { useEffect, useRef } from 'react';

const AmbientVisualizer: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let audioContext: AudioContext;
        let analyser: AnalyserNode;
        let source: MediaStreamAudioSourceNode;
        let dataArray: Uint8Array;
        let animationFrameId: number;

        const setupAudio = async () => {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
                analyser = audioContext.createAnalyser();
                analyser.fftSize = 256;
                source = audioContext.createMediaStreamSource(stream);
                source.connect(analyser);
                dataArray = new Uint8Array(analyser.frequencyBinCount);
                draw();
            } catch (err) {
                console.error('Error accessing microphone for visualizer:', err);
            }
        };

        const draw = () => {
            animationFrameId = requestAnimationFrame(draw);
            if (!analyser || !dataArray || !ctx || !canvas) return;

            analyser.getByteFrequencyData(dataArray);

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            const average = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
            const normalizedAvg = (average / 255); // value between 0 and 1

            // Draw subtle background pulses
            const pulseRadius = 50 + normalizedAvg * 150;
            const gradient = ctx.createRadialGradient(canvas.width / 2, canvas.height, 0, canvas.width / 2, canvas.height, pulseRadius * 2);
            gradient.addColorStop(0, `rgba(29, 78, 216, ${normalizedAvg * 0.05})`); // blue-700
            gradient.addColorStop(1, 'rgba(29, 78, 216, 0)');
            
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

             // Draw subtle bottom line
            const lineWidth = canvas.width;
            const lineHeight = 1 + normalizedAvg * 4;
            ctx.fillStyle = `rgba(59, 130, 246, ${0.1 + normalizedAvg * 0.2})`; // blue-500
            ctx.fillRect(0, canvas.height - lineHeight, lineWidth, lineHeight);
        };

        const resizeCanvas = () => {
            if (canvas) {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }
        };

        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();
        setupAudio();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
            if (audioContext) {
                audioContext.close();
            }
        };
    }, []);

    return <canvas ref={canvasRef} className="absolute inset-0 z-0 w-full h-full" />;
};

export default AmbientVisualizer;
