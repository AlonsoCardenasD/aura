import React from 'react';
import { Ability } from '../types.ts';

interface SmartActionProps {
    action: Ability;
    onClick: () => void;
}

const SmartAction: React.FC<SmartActionProps> = ({ action, onClick }) => {
    return (
        <button 
            onClick={onClick}
            className="flex items-center gap-2 text-sm text-slate-300 bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700 hover:border-slate-600 rounded-lg px-3 py-2 transition-all relative group"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
            <span className="font-semibold">{action.name}</span>
            {action.isPro && (
                <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.5 text-[10px] font-bold text-amber-800 bg-amber-300 border border-amber-400 rounded-full">
                    PRO
                </span>
            )}
        </button>
    );
};

export default SmartAction;