
import React, { useState, useEffect, useRef } from 'react';

interface SpeechRecognition {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    onresult: (event: any) => void;
    onend: () => void;
    onerror: (event: any) => void;
    start: () => void;
    stop: () => void;
}

declare var webkitSpeechRecognition: {
    new(): SpeechRecognition;
};

interface AuraCoreProps {
    onActivate?: () => void;
    onMemoryCapture?: (text: string) => void;
    isCentral: boolean;
}

const AuraCore: React.FC<AuraCoreProps> = ({ onActivate, onMemoryCapture, isCentral }) => {
    const [status, setStatus] = useState<'idle' | 'listening' | 'processing'>('idle');
    const recognitionRef = useRef<SpeechRecognition | null>(null);

    useEffect(() => {
        if (typeof window === 'undefined' || !('webkitSpeechRecognition' in window)) {
            console.error("Speech recognition not supported");
            return;
        }

        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'es-MX';

        recognition.onresult = (event) => {
            const finalTranscript = event.results[0][0].transcript;
            setStatus('processing');
            if (onMemoryCapture) {
                onMemoryCapture(finalTranscript);
            }
            // Let parent component control status reset after processing
            setTimeout(() => setStatus('idle'), 1500);
        };

        recognition.onend = () => {
             if (status === 'listening') {
                setStatus('idle');
            }
        };
        
        recognition.onerror = (event) => {
            console.error("Speech recognition error", event.error);
            setStatus('idle');
        };

        recognitionRef.current = recognition;
    }, [onMemoryCapture, status]);

    const handleInteractionStart = () => {
        if (isCentral && onActivate) {
            onActivate();
            return;
        }
        
        if (recognitionRef.current && status === 'idle' && onMemoryCapture) {
            recognitionRef.current.start();
            setStatus('listening');
        }
    };

    const handleInteractionEnd = () => {
        if (recognitionRef.current && status === 'listening') {
            recognitionRef.current.stop();
        }
    };
    
    const getActivationText = () => {
        return "Activar Aura";
    };

    if (isCentral) {
        return (
            <div className="fixed inset-0 bg-slate-900 flex flex-col items-center justify-center text-center p-8">
                <button 
                    onClick={handleInteractionStart} 
                    className="group relative"
                >
                    <div className={'absolute -inset-2 rounded-full blur-2xl transition-opacity duration-500 bg-blue-500 opacity-20 group-hover:opacity-40'}></div>
                     <div className="relative w-40 h-40 bg-slate-800 rounded-full flex items-center justify-center border border-slate-700 shadow-2xl shadow-black">
                        <div className="w-20 h-20 bg-blue-500 rounded-full shadow-lg shadow-blue-500/50 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5a6 6 0 00-6-6v-1.5a6 6 0 00-6 6v1.5a6 6 0 006 6z" /></svg>
                        </div>
                    </div>
                </button>
                <h1 className="text-4xl font-bold text-white mt-12">{getActivationText()}</h1>
                <p className="text-lg text-slate-400 mt-4 max-w-md">Presiona el núcleo para comenzar tu simbiosis. Aura es un sistema persistente que aprende y crece contigo.</p>
            </div>
        )
    }

    const sizeClasses = "w-20 h-20";
    const iconSizeClasses = "w-8 h-8";

    return (
        <button
            onMouseDown={handleInteractionStart}
            onMouseUp={handleInteractionEnd}
            onTouchStart={handleInteractionStart}
            onTouchEnd={handleInteractionEnd}
            disabled={status === 'processing'}
            className={`relative ${sizeClasses} rounded-full flex items-center justify-center transition-all duration-300 ease-in-out focus:outline-none shadow-2xl shadow-black disabled:cursor-wait
                ${status === 'listening' ? 'bg-blue-500 scale-110' : 'bg-slate-800 border border-slate-700'}
                ${status === 'processing' ? 'bg-slate-700' : ''}
            `}
        >
             <div className={`absolute inset-0 rounded-full transition-all duration-500
                ${status === 'listening' ? 'bg-blue-400 animate-ping opacity-60' : ''}
             `}></div>
             
             <div className={`absolute inset-0 rounded-full border-2 border-slate-500 animate-spin ${status === 'processing' ? 'opacity-100' : 'opacity-0'}`} style={{animationDuration: '1s'}}></div>
             
             <div className="relative z-10 text-white">
                <svg xmlns="http://www.w3.org/2000/svg" className={iconSizeClasses} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    {status === 'idle' && <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5a6 6 0 00-6-6v-1.5a6 6 0 00-6 6v1.5a6 6 0 006 6z" />}
                    {status === 'listening' && <path strokeLinecap="round" strokeLinejoin="round" d="M12 7.5a6 6 0 016 6v1.5a6 6 0 01-6 6v1.5a6 6 0 01-6-6v-1.5a6 6 0 016-6z" />}
                    {status === 'processing' && <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z" />}
                </svg>
             </div>

        </button>
    );
};

export default AuraCore;
