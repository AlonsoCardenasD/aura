import React from 'react';
import { Entity } from '../types.ts';
import { ENTITY_TYPE_MAP } from '../constants.tsx';

interface EntityBadgeProps {
    entity: Entity;
    onClick: () => void;
}

const EntityBadge: React.FC<EntityBadgeProps> = ({ entity, onClick }) => {
    const { color, icon } = ENTITY_TYPE_MAP[entity.type] || {};
    return (
        <button 
            onClick={onClick}
            className={`flex items-center gap-2 text-xs font-medium px-2.5 py-1 rounded-full border ${color} hover:opacity-80 transition-opacity`}
        >
            {icon}
            <span>{entity.text}</span>
        </button>
    );
};

export default EntityBadge;