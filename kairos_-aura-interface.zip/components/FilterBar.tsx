import React from 'react';
import { PillarKey } from '../types.ts';
import { PILLARS } from '../constants.tsx';

interface FilterBarProps {
    activePillar: PillarKey | null;
    onPillarClick: (pillar: PillarKey | null) => void;
}

const FilterBar: React.FC<FilterBarProps> = ({ activePillar, onPillarClick }) => {
    return (
        <nav className="flex items-center gap-2">
            <button
                onClick={() => onPillarClick(null)}
                className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors
                    ${activePillar === null ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}
                `}
            >
                Todo
            </button>
            {PILLARS.map(pillar => (
                 <button
                    key={pillar.key}
                    onClick={() => onPillarClick(pillar.key)}
                    className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors
                        ${activePillar === pillar.key ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}
                    `}
                >
                    {pillar.name}
                </button>
            ))}
        </nav>
    );
};

export default FilterBar;
