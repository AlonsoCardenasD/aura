import { ReactNode } from 'react';

export enum PillarKey {
  PRODUCTIVITY = 'PRODUCTIVITY',
  WELLBEING = 'WELLBEING',
  KNOWLEDGE = 'KNOWLEDGE',
  PROSPERITY = 'PROSPERITY',
  SECURITY = 'SECURITY',
  SOCIAL = 'SOCIAL',
}

export enum AutonomyLevel {
  ASSISTANT = 'Asistente',
  COLLABORATOR = 'Colaborador',
  SYMBIOTE = 'Simbionte',
}

export interface Ability {
    name: string;
    prompt: string;
    isPro?: boolean;
}

export interface Pillar {
  key: PillarKey;
  name:string;
  description: string;
  icon: ReactNode;
  abilities?: Ability[];
}

export enum MessageSender {
  USER = 'USER',
  AURA = 'AURA',
}

export interface Message {
  id: string;
  sender: MessageSender;
  text: string;
}

export enum EntityType {
    PERSON = 'PERSON',
    ORGANIZATION = 'ORGANIZATION',
    DATE = 'DATE',
    TASK = 'TASK'
}

export interface Entity {
    text: string;
    type: EntityType;
    details?: string;
}

export interface MemoryNode {
    id?: string;
    pillarKey: PillarKey;
    title: string;
    createdAt: string;
    content: string;
    entities?: Entity[];
}

export enum WorkflowStepType {
    TRIGGER = 'TRIGGER',
    ACTION = 'ACTION',
    CONDITION = 'CONDITION',
    OUTPUT = 'OUTPUT'
}

export interface WorkflowStep {
    type: WorkflowStepType;
    description: string;
    icon: string;
}